<?php
/**
 * @copyright	Copyright (C) 2011 Simplify Your Web, Inc. All rights reserved.
 * @license		GNU General Public License version 3 or later; see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

class JElementMessage extends JElement {
		
	public $_name = 'Message';

	function fetchElement($name, $value, &$node, $control_name) {
		
		$html = '';
		
		$message = trim($node->attributes('text'));
		$message_type = trim($node->attributes('style'));
				
		if ($message_type == 'example') {
			$html .= '<span style="color: #999999;">';
			if ($message) {
				$html .= JText::_($message);
			}
			$html .= '</span>';
		} else {	
		
			$style = '';

			switch ($message_type) {
				case 'warning':
					$style = 'border: 1px solid #FBEED5; background-color: #FCF8E3; color: #C09853;';
					break;
				case 'error':
					$style = 'border: 1px solid #EED3D7; background-color: #F2DEDE; color: #B94A48;';
					break;
				case 'info':
					$style = 'border: 1px solid #BCE8F1; background-color: #D9EDF7; color: #3A87AD';
					break;
				default: /* message/success */
					$style = 'border: 1px solid #D6E9C6; background-color: #DFF0D8; color: #468847;';
					break;
			}
			
			$html .= '<div style="margin: 5px 0; padding: 8px 35px 8px 14px; border-radius: 4px; '.$style.'">';		
			$html .= '<span>';
			if ($message) {
				$html .= JText::_($message);
			}
			$html .= '</span>';
			$html .= '</div>';
		}
		
		return $html;
	}

}
?>