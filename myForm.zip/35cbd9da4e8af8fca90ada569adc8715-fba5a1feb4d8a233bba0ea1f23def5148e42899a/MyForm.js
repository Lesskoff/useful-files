// $(document).ready(function() {

//   $("#form_id").submit(function() {
//     $.ajax({
//       type: "POST",
//       url: "mail.php",
//       data: $(this).serialize()
//     }).done(function() {
//       $(this).find("input").val("");
//       alert("Спасибо за заявку! Скоро мы с вами свяжемся.");
//       $("#form_id").trigger("reset"); // перезапуск формы
//       grecaptcha.reset(); // перезапуск рекапчи
//     });
//     return false;
//   });

// });

$(document).ready(function () {
$("#form_id").submit(function () {
// Получение ID формы
var formID = $(this).attr('id');
// Добавление решётки к имени ID
var formNm = $('#' + formID);
$.ajax({
  type: "POST",
  url: 'mail.php',
  data: formNm.serialize(),
  success: function (data) {
    // Вывод текста результата отправки
    $(formNm).html(data);
  },
  error: function (jqXHR, text, error) {
    // Вывод текста ошибки отправки
    $(formNm).html(error);     
  }
});
return false;
});

$('#reload').click(function(){
$("#form_id").trigger("reset"); // перезапуск формы
grecaptcha.reset(); // перезапуск рекапчи
})
});