<?php
require_once "SendMailSmtpClass.php"; // подключаем класс SendMailSmtpClass для отправки почты
require_once "recaptchalib.php"; // подключаем класс для проверки reCaptcha

$secret    = "SECRET_KEY";
$reCaptcha = new ReCaptcha($secret);

$response = null;

// if submitted check response
if ($_POST["g-recaptcha-response"])
{
  $response = $reCaptcha->verifyResponse(
    $_SERVER["REMOTE_ADDR"],
    $_POST["g-recaptcha-response"]
  );
}

$mailSMTP = new SendMailSmtpClass('iutas@bk.ru', 'PASSWORD', 'ssl://smtp.mail.ru', 465, "UTF-8");
// $mailSMTP = new SendMailSmtpClass('логин', 'пароль', 'хост', 'порт', 'кодировка письма');
 
// от кого
$from = array(
    "Gleb", // Имя отправителя
    "iutas@bk.ru" // почта отправителя
);
// кому
$to = 'iutas@bk.ru';
$subject = 'Сообщение из формы обратной связи'; //Загаловок сообщения
$name = $_POST['user_name'];
$phone = $_POST['user_phone'];
$email = $_POST['user_email'];
$textarea = $_POST['user_textarea'];
$message = "
  <html>
    <head>
      <title>$subject</title>
    </head>
    <body>
      <h2>Заполнена форма обратной связи на сайте sitename.ru</h2>
      <h4>Данные пользователя:</h4>
      <p>Имя: $name</p>
      <p>Телефон: $phone</p>
      <p>E-mail: $email</p>
      <p>Сообщение: $textarea</p>
    </body>
  </html>"; //Текст нащего сообщения можно использовать HTML теги
// Переменные с сообщениями для пользователя
$reloadButton = '<a id="reload-button" onclick="location.reload();return false;" href="javascript:void(0);">Отправить еще раз</a>';
$success = '<div id="success">Ваше сообщение успешно отправлено. Спасибо!</div>';
$error = '<div id="error">Пожалуйста, заполните все обязательные поля</div>';
 
// отправляем письмо
if (isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response']))
{
  if (isset($_POST['user_name']) && !empty($_POST['user_name']) && isset($_POST['user_email']) && !empty($_POST['user_email']) && isset($_POST['user_textarea']) && !empty($_POST['user_textarea'])) {
    $result =  $mailSMTP->send($to, $subject, $message, $from);
    // $result =  $mailSMTP->send('Кому письмо', 'Тема письма', 'Текст письма', 'Отправитель письма');
    if($result === true){
      echo $success;
      echo $reloadButton;
    }else{
      echo '<div id="error">Ошибка отправки формы: ' . $result . '</div>';
      echo $reloadButton;
    }
  } else {
    echo $error;
    echo $reloadButton;
  }
  
} else {
  echo $error;
  echo $reloadButton;
}